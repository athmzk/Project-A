<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoSupply - Dashboard Konstruksi Berkelanjutan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .navbar-brand { font-weight: bold; color: #198754 !important; }
        .card-counter { border-left: 5px solid #198754; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">EcoSupply Construction</a>
        </div>
    </nav>

    <div class="container">
        
        <?php if(isset($_GET['status'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php 
                    if($_GET['status'] == 'success_add') echo "Data material berhasil ditambahkan!";
                    if($_GET['status'] == 'success_delete') echo "Data material berhasil dihapus!";
                    if($_GET['status'] == 'success_update') echo "Data material berhasil diperbarui!";
                    if($_GET['status'] == 'success_waste') echo "Data limbah berhasil dicatat!";
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card shadow-sm card-counter p-3 bg-white">
                    <h6 class="text-muted">Total Stok Material Aktif</h6>
                    <?php 
                        $res = $conn->query("SELECT SUM(stok_saat_ini) as total FROM materials");
                        $data = $res->fetch_assoc();
                        echo "<h3 class='fw-bold text-success'>".($data['total'] ?? 0)." Unit</h3>";
                    ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm card-counter p-3 bg-white" style="border-left-color: #0dcaf0;">
                    <h6 class="text-muted">Vendor Bersertifikasi Hijau</h6>
                    <?php 
                        $res = $conn->query("SELECT COUNT(*) as total FROM vendors WHERE sertifikasi_hijau='Ya'");
                        $data = $res->fetch_assoc();
                        echo "<h3 class='fw-bold text-info'>".$data['total']." Vendor</h3>";
                    ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm card-counter p-3 bg-white" style="border-left-color: #dc3545;">
                    <h6 class="text-muted">Log Limbah Terdeteksi</h6>
                    <?php 
                        $res = $conn->query("SELECT SUM(jumlah_limbah) as total FROM waste_logs");
                        $data = $res->fetch_assoc();
                        echo "<h3 class='fw-bold text-danger'>".($data['total'] ?? 0)." Kg</h3>";
                    ?>
                </div>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                <h5 class="mb-0 fw-bold text-secondary">Manajemen Rantai Pasok Berkelanjutan</h5>
                <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalTambah">+ Tambah Material</button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Foto</th>
                                <th>Nama Material</th>
                                <th>Kategori</th>
                                <th>Vendor Pemasok</th>
                                <th class="text-center">Stok Aktif</th>
                                <th class="text-center">Total Limbah</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT m.id, m.nama_material, m.kategori, m.stok_saat_ini, m.satuan, m.foto_material,
                                           v.id as vendor_id, v.nama_vendor, v.kontak, v.sertifikasi_hijau,
                                           COALESCE(SUM(w.jumlah_limbah), 0) as total_limbah
                                    FROM materials m
                                    LEFT JOIN supply_orders so ON m.id = so.material_id
                                    LEFT JOIN vendors v ON so.vendor_id = v.id
                                    LEFT JOIN waste_logs w ON m.id = w.material_id
                                    GROUP BY m.id";
                            
                            $result = $conn->query($sql);
                            
                            // Siapkan variabel untuk menampung kode modal di luar tabel
                            $modals_html = "";

                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    $foto = !empty($row['foto_material']) ? 'uploads/' . $row['foto_material'] : 'https://via.placeholder.com/100x70?text=No+Image';
                                    echo "<tr>";
                                    echo "<td><img src='$foto' class='img-thumbnail' style='width: 80px; height: 60px; object-fit: cover;'></td>";
                                    echo "<td><span class='fw-bold'>{$row['nama_material']}</span></td>";
                                    echo "<td><span class='badge bg-secondary'>{$row['kategori']}</span></td>";
                                    echo "<td>{$row['nama_vendor']}</td>";
                                    echo "<td class='text-center fw-bold text-success'>{$row['stok_saat_ini']} {$row['satuan']}</td>";
                                    echo "<td class='text-center text-danger fw-bold'>{$row['total_limbah']} Kg</td>";
                                    echo "<td class='text-center'>
                                        <button class='btn btn-warning btn-sm text-dark fw-bold me-1 mb-1' data-bs-toggle='modal' data-bs-target='#modalLimbah{$row['id']}'>+ Limbah</button>
                                        <button class='btn btn-primary btn-sm me-1 mb-1' data-bs-toggle='modal' data-bs-target='#modalEdit{$row['id']}'>Edit</button>
                                        <a href='index.php?action=material_delete&id={$row['id']}' class='btn btn-danger btn-sm mb-1' onclick='return confirm(\"Hapus material ini?\")'>Hapus</a>
                                    </td>";
                                    echo "</tr>";

                                    $ya_selected = ($row['sertifikasi_hijau'] == 'Ya') ? 'selected' : '';
                                    $tidak_selected = ($row['sertifikasi_hijau'] == 'Tidak') ? 'selected' : '';

                                    // Simpan kode modal ke dalam variabel, BUKAN di-echo di dalam tabel
                                    $modals_html .= "
                                    <div class='modal fade' id='modalLimbah{$row['id']}' tabindex='-1' aria-hidden='true'>
                                        <div class='modal-dialog'>
                                            <form action='index.php?action=waste_store' method='POST' class='modal-content'>
                                                <div class='modal-header bg-warning'><h5 class='modal-title'>Catat Limbah: {$row['nama_material']}</h5></div>
                                                <div class='modal-body'>
                                                    <input type='hidden' name='material_id' value='{$row['id']}'>
                                                    <label>Jumlah Limbah (Kg)</label>
                                                    <input type='number' name='jumlah_limbah' class='form-control' required>
                                                </div>
                                                <div class='modal-footer'><button type='submit' class='btn btn-dark'>Simpan</button></div>
                                            </form>
                                        </div>
                                    </div>

                                    <div class='modal fade' id='modalEdit{$row['id']}' tabindex='-1' aria-hidden='true'>
                                        <div class='modal-dialog'>
                                            <form action='index.php?action=material_update' method='POST' enctype='multipart/form-data' class='modal-content'>
                                                <div class='modal-header'><h5 class='modal-title'>Edit Material: {$row['nama_material']}</h5></div>
                                                <div class='modal-body'>
                                                    <input type='hidden' name='id' value='{$row['id']}'>
                                                    <input type='hidden' name='vendor_id' value='{$row['vendor_id']}'>
                                                    
                                                    <label>Nama Material</label>
                                                    <input type='text' name='nama_material' class='form-control mb-2' value='{$row['nama_material']}' required>
                                                    
                                                    <label>Kategori</label>
                                                    <input type='text' name='kategori' class='form-control mb-2' value='{$row['kategori']}' required>
                                                    
                                                    <div class='row mb-2'>
                                                        <div class='col-6'><label>Stok</label><input type='number' name='stok_saat_ini' class='form-control' value='{$row['stok_saat_ini']}' required></div>
                                                        <div class='col-6'><label>Satuan</label><input type='text' name='satuan' class='form-control' value='{$row['satuan']}' required></div>
                                                    </div>
                                                    
                                                    <label>Ganti Foto (Opsional)</label>
                                                    <input type='file' name='foto_material' class='form-control mb-2'>
                                                    
                                                    <hr>
                                                    <h6 class='fw-bold text-secondary mb-2'>Data Vendor Pemasok</h6>
                                                    
                                                    <label>Nama Vendor</label>
                                                    <input type='text' name='nama_vendor' class='form-control mb-2' value='{$row['nama_vendor']}' required>
                                                    
                                                    <label>Kontak</label>
                                                    <input type='text' name='kontak' class='form-control mb-2' value='{$row['kontak']}' required>
                                                    
                                                    <label>Sertifikasi Hijau</label>
                                                    <select name='sertifikasi_hijau' class='form-select'>
                                                        <option value='Ya' $ya_selected>Ya</option>
                                                        <option value='Tidak' $tidak_selected>Tidak</option>
                                                    </select>
                                                </div>
                                                <div class='modal-footer'><button type='submit' class='btn btn-primary'>Simpan Perubahan</button></div>
                                            </form>
                                        </div>
                                    </div>";
                                }
                            } else {
                                echo "<tr><td colspan='7' class='text-center py-4 text-muted'>Belum ada data material.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php 
        // Cetak semua Modal di luar tabel dan container utama
        echo $modals_html; 
    ?>

    <div class="modal fade" id="modalTambah" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form action="index.php?action=material_store" method="POST" enctype="multipart/form-data" class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Tambah Material</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label>Nama Material</label>
                    <input type="text" name="nama_material" class="form-control mb-2" required>
                    <label>Kategori</label>
                    <input type="text" name="kategori" class="form-control mb-2" required>
                    <div class="row">
                        <div class="col-6"><label>Stok</label><input type="number" name="stok_saat_ini" class="form-control" value="0" required></div>
                        <div class="col-6"><label>Satuan</label><input type="text" name="satuan" class="form-control" required></div>
                    </div>
                    <label class="mt-2">Upload Foto</label>
                    <input type="file" name="foto_material" class="form-control" required>
                    <hr>
                    <label>Nama Vendor</label>
                    <input type="text" name="nama_vendor" class="form-control mb-2" required>
                    <label>Kontak</label>
                    <input type="text" name="kontak" class="form-control mb-2" required>
                    <label>Sertifikasi Hijau</label>
                    <select name="sertifikasi_hijau" class="form-select"><option value="Ya">Ya</option><option value="Tidak">Tidak</option></select>
                    <input type="hidden" name="alamat" value="Alamat Terdaftar">
                </div>
                <div class="modal-footer"><button type="submit" class="btn btn-success">Simpan</button></div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>