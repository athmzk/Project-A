<?php

require_once 'config.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'dashboard';

switch ($action) {
    
    case 'material_store':
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nama_material = $_POST['nama_material'];
            $kategori      = $_POST['kategori'];
            $stok_saat_ini = $_POST['stok_saat_ini'];
            $satuan        = $_POST['satuan'];
            
            $nama_vendor       = $_POST['nama_vendor'];
            $kontak            = $_POST['kontak'];
            $alamat            = $_POST['alamat'];
            $sertifikasi_hijau = $_POST['sertifikasi_hijau'];
            
            $nama_file = $_FILES['foto_material']['name'];
            $tmp_file  = $_FILES['foto_material']['tmp_name'];
            
            $ekstensi_diperbolehkan = ['jpg', 'jpeg', 'png'];
            $x = explode('.', $nama_file);
            $ekstensi = strtolower(end($x));
            
            if (in_array($ekstensi, $ekstensi_diperbolehkan) === true) {
                $nama_file_baru = time() . '_' . $nama_file;
                $folder_tujuan  = 'uploads/' . $nama_file_baru;
                
                if (move_uploaded_file($tmp_file, $folder_tujuan)) {
                    
                    $query_vendor = "INSERT INTO vendors (nama_vendor, kontak, alamat, sertifikasi_hijau) 
                                     VALUES ('$nama_vendor', '$kontak', '$alamat', '$sertifikasi_hijau')";
                    $conn->query($query_vendor);
                    $vendor_id = $conn->insert_id; 
                    
                    $query_material = "INSERT INTO materials (nama_material, kategori, stok_saat_ini, satuan, foto_material) 
                                       VALUES ('$nama_material', '$kategori', '$stok_saat_ini', '$satuan', '$nama_file_baru')";
                    $conn->query($query_material);
                    $material_id = $conn->insert_id; 
                    
                    $query_supply = "INSERT INTO supply_orders (vendor_id, material_id, jumlah_masuk, tanggal_masuk) 
                                     VALUES ('$vendor_id', '$material_id', '$stok_saat_ini', CURDATE())";
                    $conn->query($query_supply);

                    header("Location: index.php?action=dashboard&status=success_add");
                }
            } else {
                header("Location: index.php?action=dashboard&status=invalid_file");
            }
        }
        break;

    case 'material_update':
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $id            = $_POST['id'];
            $vendor_id     = $_POST['vendor_id']; 
            $nama_material = $_POST['nama_material'];
            $kategori      = $_POST['kategori'];
            $stok_saat_ini = $_POST['stok_saat_ini'];
            $satuan        = $_POST['satuan'];

            $nama_vendor       = $_POST['nama_vendor'];
            $kontak            = $_POST['kontak'];
            $sertifikasi_hijau = $_POST['sertifikasi_hijau'];

            if (!empty($_FILES['foto_material']['name'])) {
                $nama_file = $_FILES['foto_material']['name'];
                $tmp_file  = $_FILES['foto_material']['tmp_name'];
                $x = explode('.', $nama_file);
                $ekstensi = strtolower(end($x));
                $ekstensi_diperbolehkan = ['jpg', 'jpeg', 'png'];

                if (in_array($ekstensi, $ekstensi_diperbolehkan)) {
                    $res = $conn->query("SELECT foto_material FROM materials WHERE id = $id");
                    $row = $res->fetch_assoc();
                    if ($row['foto_material'] && file_exists('uploads/' . $row['foto_material'])) {
                        unlink('uploads/' . $row['foto_material']);
                    }

                    $nama_file_baru = time() . '_' . $nama_file;
                    move_uploaded_file($tmp_file, 'uploads/' . $nama_file_baru);

                    $query = "UPDATE materials SET nama_material='$nama_material', kategori='$kategori', stok_saat_ini='$stok_saat_ini', satuan='$satuan', foto_material='$nama_file_baru' WHERE id=$id";
                } else {
                    header("Location: index.php?action=dashboard&status=invalid_file");
                    exit;
                }
            } else {
                $query = "UPDATE materials SET nama_material='$nama_material', kategori='$kategori', stok_saat_ini='$stok_saat_ini', satuan='$satuan' WHERE id=$id";
            }

            if ($conn->query($query)) {
                if (!empty($vendor_id)) {
                    $query_vendor = "UPDATE vendors SET nama_vendor='$nama_vendor', kontak='$kontak', sertifikasi_hijau='$sertifikasi_hijau' WHERE id=$vendor_id";
                    $conn->query($query_vendor);
                }
                header("Location: index.php?action=dashboard&status=success_update");
            } else {
                echo "Gagal mengupdate data: " . $conn->error;
            }
        }
        break;

    case 'waste_store':
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $material_id   = $_POST['material_id'];
            $jumlah_limbah = $_POST['jumlah_limbah'];
            
            $query_waste = "INSERT INTO waste_logs (material_id, jumlah_limbah) VALUES ('$material_id', '$jumlah_limbah')";
            if ($conn->query($query_waste)) {
                header("Location: index.php?action=dashboard&status=success_waste");
            } else {
                echo "Gagal mencatat limbah: " . $conn->error;
            }
        }
        break;

    // Bagian hapus yang sudah diperbarui agar vendor juga terhapus
    case 'material_delete':
        $id = $_GET['id'];
        
        // 1. Ambil foto_material dan vendor_id sebelum data dihapus
        $res = $conn->query("SELECT m.foto_material, so.vendor_id 
                             FROM materials m 
                             LEFT JOIN supply_orders so ON m.id = so.material_id 
                             WHERE m.id = $id");
        $row = $res->fetch_assoc();
        
        // 2. Hapus file foto dari folder
        if ($row && $row['foto_material'] && file_exists('uploads/' . $row['foto_material'])) {
            unlink('uploads/' . $row['foto_material']);
        }
        
        $vendor_id = $row['vendor_id'] ?? null;

        // 3. Hapus data relasi agar tidak terjadi error (foreign key safe)
        $conn->query("DELETE FROM waste_logs WHERE material_id = $id");
        $conn->query("DELETE FROM supply_orders WHERE material_id = $id");

        // 4. Hapus data material utama
        $query = "DELETE FROM materials WHERE id = $id";
        if ($conn->query($query)) {
            // 5. Hapus data vendor yang berelasi
            if ($vendor_id) {
                $conn->query("DELETE FROM vendors WHERE id = $vendor_id");
            }
            header("Location: index.php?action=dashboard&status=success_delete");
        } else {
            echo "Gagal menghapus material: " . $conn->error;
        }
        break;

    case 'dashboard':
    default:
        include 'view.php';
        break;
}
?>